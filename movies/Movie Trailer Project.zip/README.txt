Entertainment_center_P1 version 1.0 08/18/2015 -- README.TXT

GENERAL USAGE NOTES
--------------------
- Program created and only tested on Windows 8.1 64-
bit Operating System Google Chrome version 44.

- To execute, double-click on the fresh_tomatoes icon. Be aware that there is no undo (after double clicking the program icon for execution)

- This program was created for users to see my 6 favorite movies and watch the movie trailers.  This program includes the movie poster, movie title, movie story line, movie release date, actors and the movie trailer.  Double click on the movie poster of choice to view the movie trailer.

- This program requires no installation.  This program uses a web server and a web browser.

The Entertainment_center_P1
----------------------------
Entertainment_center_P1 is being developed by:
Monique Bennett-Lowe

The Entertainment_center_P1 can be reached at:

Email: mbennettlowe@gmail.com

Third Party Libraries
----------------------
Entertainment_center_P1 makes use of fresh tomatoes.py third party library which is made available under different license conditions.  

